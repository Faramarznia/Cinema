import React from 'react'

function NotFound() {
  return '404 not found!'
}

export default NotFound
